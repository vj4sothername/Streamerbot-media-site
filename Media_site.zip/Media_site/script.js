//let hideTimer; // Variable to hold the timer

server="ws://localhost:8080/";
const ws = new WebSocket(server);

//Enable all Events
ws.onopen = function () {
  ws.send(JSON.stringify(
    {
      "request": "Subscribe",
      "events": {
        "General":["Custom"]
      },
      "id": "123"
    }
  ));
 };

 ws.onmessage = (event) => {
    // grab message and parse JSON
    const msg = event.data;
    const wsdata = JSON.parse(msg);
    console.log(wsdata);

    //const  mediafileLocation = wsdata.data.media.mediaLocation;
    //const  mediaFilename = wsdata.data.media.mediaName;
    //const  type = wsdata.data.media.type;
    //const  mediafilepath = mediafileLocation + mediaFilename + '.' + type;
    const  mediaFilePath = wsdata.data.media.mediaLocation

    const pathSegments = wsdata.data.media.mediaLocation.split("/");

    // Extract the file name and extension from the last path segment
    const fileName = pathSegments[pathSegments.length - 1];
    const fileNameParts = fileName.split(".");
    const type = fileNameParts[fileNameParts.length - 1];

    //mediaFilePath = mediaFilePath.Replace("D:\\Stream Stuff", "..");
    const  mediatimer = wsdata.data.media.timer * 1000;
    const  mediaposition = wsdata.data.media.displaytype;
    const  mediaheight = wsdata.data.media.height; 
    const  sizeType = wsdata.data.media.sizeType;
    const positionX = wsdata.data.media.positionX
    const positionY = wsdata.data.media.positionY
    let mediawidth = wsdata.data.media.width;
    const randomXY = wsdata.data.media.randomXY;
    const  aspectRatio = 16 / 9;

    //console.log(mediaFilePath);
    //console.log(type);

    if (sizeType === '1') {
    mediawidth = Math.round(wsdata.data.media.height * aspectRatio);
    } else if (sizeType === '2') {
        mediawidth = wsdata.data.media.height;
    }


    //console.log(mediaheight);
   // console.log(mediawidth + 'x' + mediaheight);


    displayMedia(mediaFilePath, type, mediatimer, mediaposition,mediawidth,mediaheight,positionX,positionY,randomXY);


 }





// Function to display GIF or WebM video
function displayMedia(url, mediatype, timer, moveDirection, width, height,positionX,positionY,randomXY) {
    document.querySelectorAll('.media-container').forEach(container => {
        clearTimeout(container.hideTimer);
    });
 
       // Create a new container for each media display
       const container = createContainer(width,height);
      //let videoDuration = null; // Variable to store the video duration


    if (mediatype === 'gif' || mediatype === 'jpeg' || mediatype === 'png' || mediatype === 'jpg' ) {
        const img = document.createElement('img');
        img.src = url;
        img.style.maxWidth = '100%'; // Ensure image fits container width
        img.style.maxHeight = '100%'; // Ensure image fits container height
        container.appendChild(img);
    } else if (mediatype === 'webm' || mediatype === 'mov' || mediatype === 'mp4' ) {
        const video = document.createElement('video');
        video.src = url;
        video.loop = false;
        video.muted = false;
        video.controls = false;
        video.style.maxWidth = '100%'; // Ensure video fits container width
        video.style.maxHeight = '100%'; // Ensure video fits container height
        container.appendChild(video);
        // Add event listener to ensure autoplay after metadata is loaded
        video.addEventListener('loadedmetadata', function() {
            video.play();
        });
        video.addEventListener('ended', function() {
            container.style.opacity = '0';
            container.remove();
        });
    }

   // Adjust container opacity based on content
   adjustContainerOpacity(container);


    // position type
    if (moveDirection === 'random') {
        randomizeContainerPosition(container,timer);
    } else if (moveDirection === 'leftToRight') {
        moveContainerLeftToRight(container,timer,width,randomXY,positionY);
    } else if (moveDirection === 'rightToLeft') {
        moveContainerRightToLeft(container,timer,width,randomXY,positionY);
    } else if (moveDirection === 'goose') {
        moveGifRandomlyToOppositeEnd(container,timer,width)
    } else if (moveDirection === 'wiggle'){
        animateContainerBetweenPoints(container,timer,width,randomXY,positionY,positionX);
    }else if (moveDirection === 'static') {
        fixedContainerPosition(container,timer,positionX,positionY);
    }else if (moveDirection === 'drift') {
        animateDrift(container, timer, width, height, randomXY,positionY,positionX)
    }else if (moveDirection === 'dvd') {
        animateDvdLogo(container, timer, width, height, randomXY,positionY,positionX)
    }else{
        console.error('Invalid moveDirection parameter');
    }
    
    // hide container
   // hideTimer = setTimeout(hideContainer, timer);
}

// function to create the dom container
function createContainer(width, height) {
    const container = document.createElement('div');
    container.className = 'media-container'; // Add a class for styling


        container.style.width = width + 'px'; // Set the width of the container with units
        container.style.height = height + 'px'; // Set the height of the container with units


    document.body.appendChild(container);

    container.hideTimer = null;
    return container;
}

// Function to adjust container opacity based on content
function adjustContainerOpacity(container) {
    // If container has no children, make it transparent
    if (!container.hasChildNodes()) {
        container.style.opacity = '0';
    } else {
        container.style.opacity = '1';
    }


}

// Function to hide the container
function hideContainer(container,mediaLength) {
    container.style.opacity = '0'; // Set container opacity to 0
    setTimeout(() => {
        container.remove(); // Remove the container from the DOM
    }, mediaLength); // Adjust the delay as needed
}

// Function for random position
function randomizeContainerPosition(container, animationDuration) {


    const maxWidth = window.innerWidth - container.offsetWidth;
    const maxHeight = window.innerHeight - container.offsetHeight;
    const randomX = Math.random() * maxWidth; // Generate random X position
    const randomY = Math.random() * maxHeight; // Generate random Y position
    container.style.left = randomX + 'px';
    container.style.top = randomY + 'px';
        // Set a timer to remove the container after the animation ends
        const removeTimer = setTimeout(() => {
            container.remove(); // Remove the container from the DOM
        }, animationDuration);
    
        // Clear the timer when the animation completes
        container.addEventListener('transitionend', function removeContainer() {
            clearTimeout(removeTimer);
            container.removeEventListener('transitionend', removeContainer); // Remove the event listener to avoid memory leaks
            container.remove(); // Remove the container from the DOM
        });
}

//Function for fixed container position top left
function fixedContainerPosition(container, animationDuration,positionX,positionY) {

    container.style.left = positionX + 'px';
    container.style.top = positionY + 'px';
        // Set a timer to remove the container after the animation ends
        const removeTimer = setTimeout(() => {
            container.remove(); // Remove the container from the DOM
        }, animationDuration);
    
        // Clear the timer when the animation completes
        container.addEventListener('remove', function clearRemoveTimer() {
            clearTimeout(removeTimer);
            container.removeEventListener('remove', clearRemoveTimer); // Remove the event listener to avoid memory leaks
        });
}


// Function to move the container from left to right
function moveContainerLeftToRight(container, animationDuration,width,randomXY,positionY) {

    const maxWidth = parseInt(window.innerWidth) + parseInt(width);

    if (randomXY === "1") {
        const randomY = Math.floor(Math.random() * (window.innerHeight - container.offsetHeight));
        container.style.top = randomY + 'px';
    } else if (randomXY === "0") {
        container.style.top = positionY + 'px';
    }


    container.style.left = '-'+ width +'px'; // Start from the left edge

    // Force reflow by accessing offsetWidth before applying transition
    container.offsetWidth;

    // Set the transition properties after reflow to trigger animation
    container.style.transition = `left ${animationDuration}ms linear`; // Set the transition duration
    container.style.left = maxWidth + 'px'; // Move to the right edge

    // Set a timer to remove the container after the animation ends
    const removeTimer = setTimeout(() => {
        container.remove(); // Remove the container from the DOM
    }, animationDuration);

    // Clear the timer when the animation completes
    container.addEventListener('transitionend', function removeContainer() {
        clearTimeout(removeTimer);
        container.removeEventListener('transitionend', removeContainer); // Remove the event listener to avoid memory leaks
        container.remove(); // Remove the container from the DOM
    });
}


// Function to move the container from right to left
function moveContainerRightToLeft(container, animationDuration,width,randomXY,positionY) {
    const maxWidth = window.innerWidth - container.offsetWidth;

    if (randomXY === "1") {
        const randomY = Math.floor(Math.random() * (window.innerHeight - container.offsetHeight));
        container.style.top = randomY + 'px';
    } else if (randomXY === "0") {
        container.style.top = positionY + 'px';
    }

    container.style.left = window.innerWidth+ 'px'; // Start from the right edge

    // Force reflow by accessing offsetWidth before applying transition
    container.offsetWidth;

    // Set the transition properties after reflow to trigger animation
    container.style.transition = `left ${animationDuration}ms linear`;
    container.style.left = -width + 'px'; // Move to the left edge

    // Set a timer to remove the container after the animation ends
    const removeTimer = setTimeout(() => {
        container.remove(); // Remove the container from the DOM
    }, animationDuration);

    // Clear the timer when the animation completes
    container.addEventListener('transitionend', function removeContainer() {
        clearTimeout(removeTimer);
        container.removeEventListener('transitionend', removeContainer); // Remove the event listener to avoid memory leaks
        container.remove(); // Remove the container from the DOM
    });
}

function moveGifRandomlyToOppositeEnd(container, animationDuration,width) {
    const maxWidth = window.innerWidth;
    const maxHeight = window.innerHeight;
    const randomY = Math.floor(Math.random() * (maxHeight - container.offsetHeight));
    const randomY2 = Math.floor(Math.random() * (maxHeight - container.offsetHeight));
    const screenWidth = maxWidth - container.clientWidth;
    const screenHeight = maxHeight - container.clientHeight;
    container.style.left = maxWidth + 'px'; // Start from the right edge
    container.style.top = `${randomY}px`;
        // Force reflow by accessing offsetWidth before applying transition
        container.offsetWidth;
        // Move the GIF to the random position
        // Set the transition properties after reflow to trigger animation
        container.style.transition = `left ${animationDuration}ms linear`; // Set the transition duration
        container.style.left = '-'+width +'px';
        container.style.top = `${randomY2}px`;


    // Set a timer to remove the container after the animation ends
    const removeTimer = setTimeout(() => {
        container.remove(); // Remove the container from the DOM
    }, animationDuration);

    // Clear the timer when the animation completes
    container.addEventListener('transitionend', function removeContainer() {
        clearTimeout(removeTimer);
        container.removeEventListener('transitionend', removeContainer); // Remove the event listener to avoid memory leaks
        container.remove(); // Remove the container from the DOM
    });
    
}

function animateContainerBetweenPoints(container, animationDuration, width, randomXY, positionY, positionX) {

    var keyframes = [
      { left: '0px', top: positionY +'px' }, // Initial position
      { left: '500px', top: '0px' }, // Second position
      { left: '1000px', top: (window.innerHeight-width)+'px' }, // Third position
      { left: (1920 - width) +'px', top: '0px' } // Final position
    ];
    var timing = {
      duration: animationDuration,
      iterations: 1 // Repeat indefinitely
    };
  
    container.animate(
      keyframes,
      timing
    );
// Set a timer to remove the container after the animation ends
const removeTimer = setTimeout(() => {
    container.remove(); // Remove the container from the DOM
}, animationDuration);

// Clear the timer when the animation completes
container.addEventListener('transitionend', function removeContainer() {
    clearTimeout(removeTimer);
    container.removeEventListener('transitionend', removeContainer); // Remove the event listener to avoid memory leaks
    container.remove(); // Remove the container from the DOM

});
}


function animateDrift(container, animationDuration, width, height, randomXY, positionX, positionY) {
    // Parse randomXY to boolean
    var randomDirection = randomXY === "1";

    // Generate random directions for bouncing
    var randomX = Math.random() < 0.5 ? -1 : 1;
    var randomY = Math.random() < 0.5 ? -1 : 1;

    // Get window dimensions
    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;

    // Calculate maximum starting position to keep the container within the screen bounds
    var maxX = windowWidth - width;
    var maxY = windowHeight - height;

    // Adjust starting position if not random
    if (!randomDirection) {
        positionX = Math.min(Math.max(positionX, 0), maxX);
        positionY = Math.min(Math.max(positionY, 0), maxY);
    } else {
        // Generate random starting position within the screen bounds
        positionX = Math.random() * maxX;
        positionY = Math.random() * maxY;
    }

    // Define keyframes based on window dimensions and random directions
    var keyframes = [
        { left: positionX + 'px', top: positionY + 'px' }, // Initial position
        { left: Math.max(Math.min(positionX + maxX * 0.25 * randomX, maxX), 0) + 'px', top: Math.max(Math.min(positionY + maxY * 0.25 * randomY, maxY), 0) + 'px' }, // Second position
        { left: Math.max(Math.min(positionX + maxX * 0.5 * randomX, maxX), 0) + 'px', top: Math.max(Math.min(positionY + maxY * 0.5 * randomY, maxY), 0) + 'px' }, // Third position
        { left: Math.max(Math.min(positionX + maxX * randomX, maxX), 0) + 'px', top: Math.max(Math.min(positionY + maxY * randomY, maxY), 0) + 'px' } // Final position
    ];

    var timing = {
        duration: animationDuration,
        iterations: 1 // Run the animation only once
    };

    container.animate(
        keyframes,
        timing
    );

    // Set a timer to remove the container after the animation ends
    const removeTimer = setTimeout(() => {
        container.style.transition = `opacity ${200}ms`;
        container.style.opacity = 0;
        // Remove the container from the DOM after fade out
        setTimeout(() => {
        container.remove();
    }, 200);
    }, animationDuration);

    // Clear the timer when the animation completes
    container.addEventListener('transitionend', function removeContainer() {
        clearTimeout(removeTimer);
        container.removeEventListener('transitionend', removeContainer); // Remove the event listener to avoid memory leaks
        container.remove(); // Remove the container from the DOM
    });
}

function animateDvdLogo(container, animationDuration, width, height, randomXY, positionX, positionY) {
    // Parse randomXY to boolean
    var randomDirection = randomXY === "1";

    // Get window dimensions
    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;

    // Calculate maximum starting position to keep the container within the screen bounds
    var maxX = windowWidth - width;
    var maxY = windowHeight - height;

    // Adjust starting position if not random
    if (!randomDirection) {
        positionX = Math.min(Math.max(positionX, 0), maxX);
        positionY = Math.min(Math.max(positionY, 0), maxY);
    } else {
        // Generate random starting position within the screen bounds
        positionX = Math.random() * (1920 - width);
        positionY = Math.random() * (1080 - height);
    }

    // Define initial position
    container.style.left = positionX + 'px';
    container.style.top = positionY + 'px';

    // Generate random directions for bouncing
    var randomX = Math.random() < 0.5 ? -1 : 1;
    var randomY = Math.random() < 0.5 ? -1 : 1;

    // Define keyframes based on window dimensions and random directions
    var keyframes = [];
    var bounceCount = 0;
    var deltaX = randomX;
    var deltaY = randomY;
    var x = positionX;
    var y = positionY;

    while (bounceCount < 10) {
        // Calculate next position
        var nextX = x + deltaX * maxX;
        var nextY = y + deltaY * maxY;

        // Reflect if hitting horizontal edges
        if (nextY < 0 || nextY + height > windowHeight) {
            deltaY *= -1;
            bounceCount++;
        }

        // Reflect if hitting vertical edges
        if (nextX < 0 || nextX + width > windowWidth) {
            deltaX *= -1;
            bounceCount++;
        }

        // Store keyframe
        keyframes.push({ left: nextX + 'px', top: nextY + 'px' });

        // Update position
        x = nextX;
        y = nextY;
    }

    var timing = {
        duration: animationDuration,
        iterations: 1 // Run the animation only once
    };

    container.animate(
        keyframes,
        timing
    );

    // Set a timer to remove the container after the animation ends
    const removeTimer = setTimeout(() => {
        container.remove(); // Remove the container from the DOM
    }, animationDuration);

    // Clear the timer when the animation completes
    container.addEventListener('transitionend', function removeContainer() {
        clearTimeout(removeTimer);
        container.removeEventListener('transitionend', removeContainer); // Remove the event listener to avoid memory leaks
        container.remove(); // Remove the container from the DOM
    });
}

